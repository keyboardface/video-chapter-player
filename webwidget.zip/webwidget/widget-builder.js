class VideoChapterWidgetBuilder {
    constructor() {
        this.parent = null;
        this.settings = {
            videoUrl: '',
            posterUrl: '',
            chapterListTitle: 'Chapters 📖',
            hideChapterListTitle: false,
            enablePreview: true,
            chapters: []
        };
        
        this.chapterPlayer = null;
        this.previewContainer = null;
        this.tempVideoElement = null;
        
        this.init();
    }

    async init() {
        // Initialize postmate communication
        try {
            this.parent = await new Postmate.Model({
                height: 800
            });
            console.log('Postmate connection established');
        } catch (error) {
            console.error('Failed to establish postmate connection:', error);
        }

        // Load initial settings if provided
        if (this.parent) {
            this.parent.get('elementStore').then(elementStore => {
                if (elementStore) {
                    this.loadSettings(elementStore);
                }
                this.emitInitialState();
            }).catch(() => {
                this.emitInitialState();
            });
        }

        this.initializeUI();
        this.bindEvents();
    }

    initializeUI() {
        // Initialize DOM elements
        this.videoUrlInput = document.getElementById('videoUrl');
        this.posterUrlInput = document.getElementById('posterUrl');
        this.chapterTitleInput = document.getElementById('chapterTitle');
        this.hideChapterTitleCheckbox = document.getElementById('hideChapterTitle');
        this.enablePreviewCheckbox = document.getElementById('enablePreview');
        this.loadVideoBtn = document.getElementById('loadVideoBtn');
        this.addChapterBtn = document.getElementById('addChapterBtn');
        this.chaptersList = document.getElementById('chaptersList');
        this.previewContainer = document.getElementById('widgetPreview');

        // Chapter modal elements
        this.chapterModal = document.getElementById('chapterModal');
        this.editingChapterId = document.getElementById('editingChapterId');
        this.chapterTimestamp = document.getElementById('chapterTimestamp');
        this.chapterName = document.getElementById('chapterName');
        this.chapterDesc = document.getElementById('chapterDesc');
        this.getCurrentTimeBtn = document.getElementById('getCurrentTimeBtn');
        this.saveChapterBtn = document.getElementById('saveChapterBtn');
        this.cancelChapterBtn = document.getElementById('cancelChapterBtn');

        // Update UI with current settings
        this.updateUI();
    }

    bindEvents() {
        // Video loading
        this.loadVideoBtn.addEventListener('click', () => this.loadVideo());
        this.videoUrlInput.addEventListener('input', () => this.updateSetting('videoUrl', this.videoUrlInput.value));
        this.posterUrlInput.addEventListener('input', () => this.updateSetting('posterUrl', this.posterUrlInput.value));

        // Settings
        this.chapterTitleInput.addEventListener('input', () => {
            this.updateSetting('chapterListTitle', this.chapterTitleInput.value);
        });
        
        this.hideChapterTitleCheckbox.addEventListener('change', () => {
            this.updateSetting('hideChapterListTitle', this.hideChapterTitleCheckbox.checked);
        });
        
        this.enablePreviewCheckbox.addEventListener('change', () => {
            this.updateSetting('enablePreview', this.enablePreviewCheckbox.checked);
        });

        // Chapter management
        this.addChapterBtn.addEventListener('click', () => this.openChapterModal());
        this.saveChapterBtn.addEventListener('click', () => this.saveChapter());
        this.cancelChapterBtn.addEventListener('click', () => this.closeChapterModal());
        this.getCurrentTimeBtn.addEventListener('click', () => this.getCurrentTime());

        // Modal close events
        this.chapterModal.querySelector('.modal-close').addEventListener('click', () => this.closeChapterModal());
        this.chapterModal.addEventListener('click', (e) => {
            if (e.target === this.chapterModal) this.closeChapterModal();
        });
    }

    loadSettings(elementStore) {
        if (elementStore.videoUrl) this.settings.videoUrl = elementStore.videoUrl;
        if (elementStore.posterUrl) this.settings.posterUrl = elementStore.posterUrl;
        if (elementStore.chapterListTitle) this.settings.chapterListTitle = elementStore.chapterListTitle;
        if (elementStore.hasOwnProperty('hideChapterListTitle')) this.settings.hideChapterListTitle = elementStore.hideChapterListTitle;
        if (elementStore.hasOwnProperty('enablePreview')) this.settings.enablePreview = elementStore.enablePreview;
        if (elementStore.chapters) this.settings.chapters = [...elementStore.chapters];
        
        this.updateUI();
        if (this.settings.videoUrl) {
            this.loadVideo();
        }
    }

    updateUI() {
        this.videoUrlInput.value = this.settings.videoUrl;
        this.posterUrlInput.value = this.settings.posterUrl;
        this.chapterTitleInput.value = this.settings.chapterListTitle;
        this.hideChapterTitleCheckbox.checked = this.settings.hideChapterListTitle;
        this.enablePreviewCheckbox.checked = this.settings.enablePreview;
        
        this.renderChaptersList();
    }

    updateSetting(key, value) {
        this.settings[key] = value;
        this.emitWidgetCode();
        this.updatePreview();
    }

    loadVideo() {
        const url = this.videoUrlInput.value.trim();
        if (!url) return;

        this.settings.videoUrl = url;
        this.addChapterBtn.disabled = false;
        
        // Create temp video element for duration and current time
        if (this.tempVideoElement) {
            this.tempVideoElement.remove();
        }
        
        this.tempVideoElement = document.createElement('video');
        this.tempVideoElement.style.display = 'none';
        this.tempVideoElement.crossOrigin = 'anonymous';
        document.body.appendChild(this.tempVideoElement);
        
        this.tempVideoElement.addEventListener('loadedmetadata', () => {
            console.log('Video loaded, duration:', this.tempVideoElement.duration);
            this.getCurrentTimeBtn.disabled = false;
        });
        
        this.tempVideoElement.src = url;
        
        this.updatePreview();
        this.emitWidgetCode();
    }

    renderChaptersList() {
        if (this.settings.chapters.length === 0) {
            this.chaptersList.innerHTML = '<p class="empty-state">Load a video to add chapters</p>';
            return;
        }

        this.chaptersList.innerHTML = this.settings.chapters.map((chapter, index) => `
            <div class="chapter-item" data-index="${index}">
                <div class="chapter-info">
                    <div class="title">${this.escapeHtml(chapter.title)}</div>
                    <div class="timestamp">${this.formatTime(chapter.timestamp)}</div>
                </div>
                <div class="chapter-actions">
                    <button class="btn btn-small btn-primary" onclick="widgetBuilder.editChapter(${index})">Edit</button>
                    <button class="btn btn-small btn-secondary" onclick="widgetBuilder.deleteChapter(${index})">Delete</button>
                </div>
            </div>
        `).join('');
    }

    openChapterModal(chapterIndex = -1) {
        if (chapterIndex >= 0) {
            // Editing existing chapter
            const chapter = this.settings.chapters[chapterIndex];
            this.editingChapterId.value = chapterIndex;
            this.chapterTimestamp.value = this.formatTime(chapter.timestamp);
            this.chapterName.value = chapter.title;
            this.chapterDesc.value = chapter.description || '';
        } else {
            // Adding new chapter
            this.editingChapterId.value = '';
            this.chapterTimestamp.value = '0:00';
            this.chapterName.value = '';
            this.chapterDesc.value = '';
        }
        
        this.chapterModal.style.display = 'block';
    }

    closeChapterModal() {
        this.chapterModal.style.display = 'none';
    }

    editChapter(index) {
        this.openChapterModal(index);
    }

    deleteChapter(index) {
        if (confirm('Are you sure you want to delete this chapter?')) {
            this.settings.chapters.splice(index, 1);
            this.renderChaptersList();
            this.emitWidgetCode();
            this.updatePreview();
        }
    }

    saveChapter() {
        const timestamp = this.parseTime(this.chapterTimestamp.value);
        const title = this.chapterName.value.trim();
        
        if (!title) {
            alert('Chapter title is required');
            return;
        }

        if (isNaN(timestamp) || timestamp < 0) {
            alert('Invalid timestamp format');
            return;
        }

        const chapter = {
            timestamp: timestamp,
            title: title,
            description: this.chapterDesc.value.trim()
        };

        const editIndex = this.editingChapterId.value;
        if (editIndex !== '') {
            // Editing existing chapter
            this.settings.chapters[parseInt(editIndex)] = chapter;
        } else {
            // Adding new chapter
            this.settings.chapters.push(chapter);
        }

        // Sort chapters by timestamp
        this.settings.chapters.sort((a, b) => a.timestamp - b.timestamp);
        
        this.renderChaptersList();
        this.closeChapterModal();
        this.emitWidgetCode();
        this.updatePreview();
    }

    getCurrentTime() {
        if (this.tempVideoElement && !isNaN(this.tempVideoElement.currentTime)) {
            this.chapterTimestamp.value = this.formatTime(this.tempVideoElement.currentTime);
        }
    }

    updatePreview() {
        const html = this.createHtml();
        this.previewContainer.innerHTML = html;
        
        // Initialize the chapter player in the preview
        setTimeout(() => {
            const previewElement = this.previewContainer.querySelector('.video-chapter-player');
            if (previewElement && window.ChapterPlayer) {
                try {
                    new ChapterPlayer(previewElement.id, this.getPlayerConfig());
                } catch (error) {
                    console.error('Preview initialization error:', error);
                }
            }
        }, 100);
    }

    getPlayerConfig() {
        return {
            videoUrl: this.settings.videoUrl,
            posterUrl: this.settings.posterUrl,
            chapterListTitle: this.settings.chapterListTitle,
            hideChapterListTitle: this.settings.hideChapterListTitle,
            isPreviewEnabled: this.settings.enablePreview,
            chapters: this.settings.chapters
        };
    }

    createHtml() {
        const config = this.getPlayerConfig();
        const configStr = JSON.stringify(config).replace(/"/g, '&quot;');
        
        return `<div class="video-chapter-player" id="chapter-player-${Date.now()}" data-config="${configStr}"></div>`;
    }

    createJS() {
        return `// Video Chapter Player Widget JS
(function() {
    // Import ChapterPlayer from CDN or include inline
    if (typeof ChapterPlayer === 'undefined') {
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/gh/your-repo/chapterplayer.js';
        document.head.appendChild(script);
    }
    
    function initChapterPlayers() {
        const players = document.querySelectorAll('.video-chapter-player');
        players.forEach((element, index) => {
            if (!element.id) {
                element.id = 'chapter-player-' + (index + 1);
            }
            
            let config = null;
            if (element.dataset.config) {
                try {
                    const configStr = element.dataset.config.replace(/&quot;/g, '"');
                    config = JSON.parse(configStr);
                    if (typeof ChapterPlayer !== 'undefined') {
                        new ChapterPlayer(element.id, config);
                    } else {
                        // Wait for script to load
                        setTimeout(() => {
                            if (typeof ChapterPlayer !== 'undefined') {
                                new ChapterPlayer(element.id, config);
                            }
                        }, 1000);
                    }
                } catch (error) {
                    console.error('Error initializing chapter player:', error);
                    element.innerHTML = '<p>Error: Invalid player configuration</p>';
                }
            }
        });
    }
    
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initChapterPlayers);
    } else {
        initChapterPlayers();
    }
})();`;
    }

    createCss() {
        return `/* Video Chapter Player Widget CSS */
@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap');

.video-chapter-player * {
    font-family: 'Roboto', Arial, sans-serif;
}

.video-chapter-player {
    display: flex;
    flex-wrap: wrap;
    gap: 25px;
    margin-bottom: 35px;
    position: relative;
    max-width: 100%;
}

.video-chapter-player .chapter-player-instance {
    display: flex;
    flex-wrap: wrap;
    gap: 25px;
    margin-bottom: 35px;
    position: relative;
    width: 100%;
}

.video-chapter-player .video-wrapper {
    flex: 3 1 400px;
    min-width: 300px;
    position: relative;
    background-color: #000;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
    display: flex;
    flex-direction: column;
}

.video-chapter-player video {
    width: 100%;
    display: block;
    flex: 1;
}

.video-chapter-player .chapter-list {
    flex: 1 1 250px;
    min-width: 200px;
    max-height: 400px;
    background-color: #fff;
    border: 1px solid #e1e8ed;
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    overflow-y: auto;
}

.video-chapter-player .chapter-list h2 {
    margin: 0 0 15px 0;
    font-size: 18px;
    color: #2c3e50;
    font-weight: 600;
}

.video-chapter-player .chapter-item {
    padding: 12px 16px;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.2s ease;
    border-left: 3px solid transparent;
    margin-bottom: 8px;
}

.video-chapter-player .chapter-item:hover {
    background-color: #f8f9fa;
    border-left-color: #3498db;
}

.video-chapter-player .chapter-item.active {
    background-color: #e3f2fd;
    border-left-color: #2196f3;
}

.video-chapter-player .chapter-item .chapter-title {
    font-weight: 500;
    color: #2c3e50;
    font-size: 14px;
    line-height: 1.4;
}

.video-chapter-player .chapter-item .chapter-time {
    font-size: 12px;
    color: #7f8c8d;
    margin-top: 4px;
}

.video-chapter-player .chapter-item .chapter-description {
    font-size: 12px;
    color: #95a5a6;
    margin-top: 6px;
    line-height: 1.3;
}

/* Responsive */
@media (max-width: 768px) {
    .video-chapter-player {
        flex-direction: column;
    }
    
    .video-chapter-player .video-wrapper,
    .video-chapter-player .chapter-list {
        flex: none;
        width: 100%;
    }
}`;
    }

    emitWidgetCode() {
        if (this.parent) {
            this.parent.emit('code', {
                html: this.createHtml(),
                js: this.createJS(),
                elementStore: { ...this.settings }
            });
        }
    }

    emitInitialState() {
        this.emitWidgetCode();
    }

    // Utility functions
    parseTime(timeStr) {
        if (!isNaN(parseFloat(timeStr))) return parseFloat(timeStr);
        
        const parts = timeStr.split(':').map(Number);
        if (parts.length === 2) return parts[0] * 60 + parts[1];
        if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
        
        return NaN;
    }

    formatTime(seconds) {
        if (isNaN(seconds) || seconds < 0) return '0:00';
        
        const h = Math.floor(seconds / 3600);
        const m = Math.floor((seconds % 3600) / 60);
        const s = Math.floor(seconds % 60);
        
        if (h > 0) {
            return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
        } else {
            return `${m}:${s.toString().padStart(2, '0')}`;
        }
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    getChapterPlayerJS() {
        // This would contain the ChapterPlayer class code
        // For now, we'll load it separately
        return '';
    }

    getChapterPlayerCSS() {
        // This would contain the ChapterPlayer CSS
        // For now, we'll load it separately
        return '';
    }
}

// Initialize the widget builder
let widgetBuilder;
document.addEventListener('DOMContentLoaded', () => {
    widgetBuilder = new VideoChapterWidgetBuilder();
});