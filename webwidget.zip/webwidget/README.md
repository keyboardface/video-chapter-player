# Video Chapter Widget for GoHighLevel

A custom video chapter widget for the GoHighLevel Funnel Builder that allows users to create interactive video players with chapter navigation.

## Features

- Interactive video player with custom controls
- Chapter-based navigation with timestamps  
- Responsive design that works on mobile and desktop
- Timeline preview on hover (optional)
- Customizable chapter list title
- Support for poster images
- Easy-to-use settings interface

## Files Structure

```
webwidget/
├── index.html              # Main widget builder interface
├── widget-builder.js       # Core widget builder logic with Postmate communication
├── styles.css             # Builder interface styles
├── chapterplayer.js       # Video player component
├── chapterplayer.css      # Video player styles
├── test.html              # Test page for development
└── README.md              # This file
```

## Development Testing

1. Open `test.html` in a web browser
2. Configure your video settings in the iframe
3. See the generated HTML/CSS/JS output
4. View the live preview at the bottom

## Widget Builder Interface

The widget builder provides:

- **Video URL Input**: MP4 video URL
- **Poster Image**: Optional poster/thumbnail image
- **Chapter List Title**: Customizable title for the chapters section
- **Timeline Preview**: Toggle for hover preview functionality
- **Chapter Management**: Add, edit, and delete chapters with timestamps

## Generated Output

The widget generates three components:

1. **HTML**: `<div>` with configuration data
2. **CSS**: Styles for the video player
3. **JavaScript**: Player initialization and functionality

## Integration Requirements

For GoHighLevel marketplace integration, this widget:

- ✅ Uses Postmate for iframe communication
- ✅ Implements required functions: `createHtml()`, `createJS()`, `createCss()`
- ✅ Emits widget code via `parent.emit('code', {...})`
- ✅ Handles `elementStore` for persisting settings
- ✅ Provides responsive, mobile-friendly output
- ✅ Avoids external dependencies in generated code
- ✅ Follows GoHighLevel widget guidelines

## Usage in Funnel Builder

Once uploaded to the GoHighLevel marketplace:

1. Users drag the widget onto their funnel page
2. Widget settings open in an iframe
3. Users configure video URL, chapters, and appearance
4. Widget generates the HTML/CSS/JS for the funnel
5. End users see the interactive video player

## Technical Details

- Built with vanilla JavaScript (no frameworks)
- Uses Postmate library for iframe communication
- Responsive CSS with mobile-first design
- Cross-browser compatible video controls
- Keyboard navigation support
- WCAG accessibility considerations

## Customization

The widget can be customized by modifying:

- `styles.css` for builder interface appearance
- `chapterplayer.css` for video player styling
- `widget-builder.js` for functionality and settings
- Chapter list layout and interaction patterns